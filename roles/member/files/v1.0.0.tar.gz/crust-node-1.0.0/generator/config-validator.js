

function validate(config) {
  return config
}

module.exports = {
  validate,
}
