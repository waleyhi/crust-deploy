# Generator

## Overview
The role of G is to convert the user's configuration into a docker compose file.

## Build docker
```shell
sudo docker build -t crustio/config-generator:latest .
```
